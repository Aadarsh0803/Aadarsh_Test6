
class Book {
    displayDetails() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publicationYear}`);
    }
}

const myBook = new Book();
myBook.title = 'Thousand Splindid suns';
myBook.author = 'Abdul';
myBook.publicationYear = 1996;

myBook.displayDetails();
