const SquaredNos = (numbers) => {
    return numbers.map((number) => number * number);
}

const numbers = [34,5,4,3,5,2,2,45,45,3,32,36];
const squaredNumbers = SquaredNos(numbers);
console.log(squaredNumbers); 