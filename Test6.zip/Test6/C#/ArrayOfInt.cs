﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test6
{
    internal class ArrayOfInt
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter size of Array");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Array values: ");
            int[] numbers = new int[size];  
            for (int i = 0; i < size; i++)
            {
                Console.Write($"Enter element {i + 1}: ");
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            int sum = 0;
            foreach(int number in numbers)
            {
                sum+= number;   
            }
            Console.WriteLine($"Sum of Array integers is: {sum}");
            double average = sum/size;
            Console.WriteLine($"Average of Array integers is: {average}");

            int max = numbers[0];
            int min = numbers[0];
            foreach(int number in numbers)
            {
                if(number > max )
                {
                    max = number;
                }
                else
                {
                    min = number;
                }
            }
            Console.WriteLine($"Maximim number in Array is: {max}");
            Console.WriteLine($"Minimum number in array is: {min}");
        }
    }
}
