﻿namespace Test6
{
    internal class GuessingGame
    {
        static void Main(string[] args)
        {
            int minRange = 1;
            int maxRange = 10;
            int attempts = 0;
            int maxAttempts = 4;
            bool guess = false;
            Random random = new Random();
            int toGuess = random.Next(minRange, maxRange + 1);

            while (attempts < maxAttempts && !guess)
            {
                Console.WriteLine("Choose a number between 1-10");
                Console.Write("Input Number: ");
                try
                {
                    string input = Console.ReadLine();
                    int userGuess = Convert.ToInt32(input);

                    if (userGuess < minRange || userGuess > maxRange)
                    {
                        Console.WriteLine($"Please choose a number between {minRange} and {maxRange}.");
                    }
                    else if (userGuess < toGuess)
                    {
                        Console.WriteLine("The number is too low.");
                        attempts++;
                    }
                    else if (userGuess > toGuess)
                    {
                        Console.WriteLine("The number is too high.");
                        attempts++;
                    }
                    else
                    {
                        Console.WriteLine("Congratulations! That's the correct number!");
                        guess = true;
                    }

                    if (attempts >= maxAttempts && !guess)
                    {
                        Console.WriteLine($"Sorry, you've reached the maximum attempts. The correct number was {toGuess}.");
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input! Please enter a valid number.");
                }
            }
        }
    }
}
