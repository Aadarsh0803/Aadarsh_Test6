﻿using System;

namespace Test6
{
    internal class PrimeNos
    {
        public static void Main()
        {
            try
            {
                Console.WriteLine("Enter a number to display prime numbers in that range: ");
                int range = Convert.ToInt32(Console.ReadLine());

                if (range <= 0)
                {
                    Console.WriteLine("Enter a positive number");
                    return; 
                }

                Console.WriteLine("Prime numbers in the range 1 to " + range);

                for (int num = 2; num <= range; num++)
                {
                    if (IsPrime(num))
                    {
                        Console.Write(num + " ");
                    }
                }

                Console.WriteLine();
            }
            catch (FormatException ex)
            {
                Console.WriteLine( ex.Message);
            }            
        }

        static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number == 2) return true;
            if (number % 2 == 0) return false;

            for (int i = 3; i <= Math.Sqrt(number); i += 2)
            {
                if (number % i == 0) return false;
            }

            return true;
        }
    }
}
